# This project is to generate .html file for Delivery Slip Ticket.

# Let's start this project as follows.
## - npm install
## - nodemon index.js / npm start

## - When the above command is executed, the index.html file is created.
 
# This is simply a Node.js script that generates Delivery Slip Ticked HTML File.
